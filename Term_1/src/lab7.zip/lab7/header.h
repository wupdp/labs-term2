#include "functions.c"
int init_x(int min, int max);

int if_letter(char s);

int if_A_letter(char s);

int if_a_letter(char s);

int choose_ex();

void get_string(char **s, int *k);

void show_string(char *str);

void task1(char *string);

void ex1();

char *string_cat(char *s1, char *s2, int start1, int start2, int n1);

void ex2();

void start_ex(void (*ex)(), int x);
